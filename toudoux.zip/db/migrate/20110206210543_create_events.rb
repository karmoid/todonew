class CreateEvents < ActiveRecord::Migration
  def self.up
    create_table :events do |t|
      t.string :description
      t.integer :operation_id
      t.text :note
      t.date :planned
      t.date :done
      t.date :cancelled
      t.text :status

      t.timestamps
    end
  end

  def self.down
    drop_table :events
  end
end
