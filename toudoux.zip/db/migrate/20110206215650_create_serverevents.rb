class CreateServerevents < ActiveRecord::Migration
  def self.up
    create_table :serverevents do |t|
      t.integer :server_id
      t.integer :event_id

      t.timestamps
    end
    
    add_index :serverevents, :server_id
    add_index :serverevents, :event_id
  end

  def self.down
    drop_table :serverevents
  end
end
