class AddTypeToServerevents < ActiveRecord::Migration
  def self.up
    add_column :serverevents, :kind, :integer
  end

  def self.down
    remove_column :serverevents, :kind
  end
end
