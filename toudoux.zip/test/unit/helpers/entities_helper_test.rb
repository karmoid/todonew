require 'test_helper'

class EntitiesHelperTest < ActionView::TestCase
end
