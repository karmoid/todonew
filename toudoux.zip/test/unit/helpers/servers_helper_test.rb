require 'test_helper'

class ServersHelperTest < ActionView::TestCase
end
