require 'test_helper'

class OpegroupsHelperTest < ActionView::TestCase
end
