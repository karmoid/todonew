require 'test_helper'

class EnvironmentsHelperTest < ActionView::TestCase
end
