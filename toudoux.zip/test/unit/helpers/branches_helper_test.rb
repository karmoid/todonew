require 'test_helper'

class BranchesHelperTest < ActionView::TestCase
end
