require 'test_helper'

class InstancesHelperTest < ActionView::TestCase
end
