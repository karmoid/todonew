# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Toudoux::Application.config.secret_token = 'e3e85c5a09496db2676fc0628c5419101e9d9e4e6d4e47d1e83e308a4e0ed7c8601e918b151225ff0855974ee36f6261e86b46c699e44231c26100680a93291b'
