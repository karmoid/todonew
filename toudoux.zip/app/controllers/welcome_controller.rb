class WelcomeController < ApplicationController
  def index
  end

  def account
    
  end
end
