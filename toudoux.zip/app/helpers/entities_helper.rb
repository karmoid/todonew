module EntitiesHelper
end
