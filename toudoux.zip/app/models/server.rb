class Server < ActiveRecord::Base
  belongs_to :branch
  has_many :instances
  has_many :serverevents, :foreign_key => "server_id",  :dependent => :destroy
  has_many :events, :through => :serverevents, :order => 'planned', :conditions => 'serverevents.kind=1'
end
