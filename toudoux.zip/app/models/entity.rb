class Entity < ActiveRecord::Base
  has_many :branches
end
