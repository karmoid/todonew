class Environment < ActiveRecord::Base
    has_many :instances
end
