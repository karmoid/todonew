class Opegroup < ActiveRecord::Base
  has_many :operations
end
