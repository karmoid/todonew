class Event < ActiveRecord::Base
  belongs_to :operation
  has_many :serverevents, :foreign_key => "event_id"
  has_one :server, :through => :serverevents, :conditions => 'serverevents.kind=1'    
  has_one :branch, :through => :serverevents, :conditions => 'serverevents.kind=2'    
end
