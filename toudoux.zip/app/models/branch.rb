class Branch < ActiveRecord::Base
  has_many :servers 
  belongs_to :entity
  has_many :serverevents, :foreign_key => "server_id",  :dependent => :destroy
  has_many :events, :through => :serverevents, :order => 'planned', :conditions => 'serverevents.kind=2'
end
